import os
import shutil

try:
    console_width = shutil.get_terminal_size().columns
except OSError:
    console_width = 80

box_width = min(50, console_width)
border = "=" * box_width

texts = [
    "ATOM PROJECT",
    "v0.0.1",
    "Добро пожаловать!"
]

banner_lines = [border]
for text in texts:
    inner_line = "|" + text.center(box_width - 2) + "|"
    banner_lines.append(inner_line)
banner_lines.append(border)

print("\n")
for line in banner_lines:
    print(line.center(console_width))
print()

servers = {
    1: ("185.169.134.3", "Phoenix"),
    2: ("185.169.134.4", "Tucson"),
    3: ("185.169.134.43", "Scottdale"),
    4: ("185.169.134.44", "Chandler"),
    5: ("185.169.134.45", "Brainburg"),
    6: ("185.169.134.5", "SaintRose"),
    7: ("185.169.134.59", "Mesa"),
    8: ("185.169.134.61", "RedRock"),
    9: ("185.169.134.107", "Yuma"),
    10: ("185.169.134.109", "Surprise"),
    11: ("185.169.134.166", "Prescott"),
    12: ("185.169.134.171", "Glendale"),
    13: ("185.169.134.172", "Kingman"),
    14: ("185.169.134.173", "Winslow"),
    15: ("185.169.134.174", "Payson"),
    16: ("80.66.82.191", "Gilbert"),
    17: ("80.66.82.190", "ShowLow"),
    18: ("80.66.82.188", "CasaGrande"),
    19: ("80.66.82.168", "Page"),
    20: ("80.66.82.159", "SunCity"),
    21: ("80.66.82.200", "QueenCreek"),
    22: ("80.66.82.144", "Sedona"),
    23: ("80.66.82.132", "Holiday"),
    24: ("80.66.82.128", "Wednesday"),
    25: ("80.66.82.113", "Yava"),
    26: ("80.66.82.82", "Faraway"),
    27: ("80.66.82.87", "Bumblebee"),
    28: ("80.66.82.54", "Christmas"),
    29: ("80.66.82.39", "Mirage"),
    30: ("80.66.82.33", "Love"),
    31: ("80.66.82.22", "Drake"),
    32: ("80.66.82.199", "Space"),
}

def print_servers():
    print("Доступные сервера:")
    for num, (ip, name) in servers.items():
        print(f"{num}: {name} ({ip})")
    print("0: Все сервера")

def get_server_selection():
    while True:
        print_servers()
        choice = input("Введите номер сервера для запуска (через запятую для нескольких) или 0 для всех: ").strip()
        if choice == '0':
            return list(servers.keys())
        else:
            parts = choice.split(',')
            try:
                selected = []
                for p in parts:
                    n = int(p.strip())
                    if n not in servers:
                        raise ValueError
                    selected.append(n)
                return selected
            except ValueError:
                print("Ошибка: введите корректные номера серверов.")

def get_int_input(prompt, min_val=1):
    while True:
        val = input(prompt).strip()
        if val.isdigit() and int(val) >= min_val:
            return int(val)
        print(f"Ошибка: введите число >= {min_val}")

def launch_raksamp(ip, port, nick):
    cmd = f'start "RakSamp" "RakSAMP Lite.exe" -h {ip} -p {port} -n {nick} -z'
    print(f"Запускаю: {cmd}")
    os.system(cmd)
    os.system('start https://t.me/Arizona_ZTeam')

def launch_homeless():
    selected_servers = get_server_selection()
    windows_count = get_int_input("Сколько окон запускать на каждом сервере? ")
    default_nick = "nick"
    nick = input(f"Введите никнейм (Enter для '{default_nick}'): ").strip()
    if not nick:
        nick = default_nick

    for server_num in selected_servers:
        ip, _ = servers[server_num]
        port = 7777
        for _ in range(windows_count):
            launch_raksamp(ip, port, nick)

def parse_account_line(line):
    parts = line.strip().split(';')
    if len(parts) != 3:
        return None
    server_part, nick, password = parts
    if ':' not in server_part:
        return None
    ip, port = server_part.split(':', 1)
    return ip, port, nick, password

def launch_organization():
    accounts_path = os.path.join("accounts", "accounts_for_organizations.txt")
    if not os.path.isfile(accounts_path):
        print(f"Файл с аккаунтами не найден: {accounts_path}")
        return

    with open(accounts_path, encoding='utf-8') as f:
        lines = f.readlines()

    accounts = []
    for line in lines:
        if not line.strip():
            continue
        parsed = parse_account_line(line)
        if parsed is None:
            print(f"Пропускаю некорректную строку: {line.strip()}")
            continue
        accounts.append(parsed)

    if not accounts:
        print("Нет корректных аккаунтов.")
        return

    for ip, port, nick, password in accounts:
        launch_raksamp(ip, port, nick)

def main():
    print("Выберите тип РакБота для запуска:")
    print("1: Нулевки")
    print("2: Орги")
    while True:
        choice = input("Введите 1 или 2: ").strip()
        if choice == '1':
            launch_homeless()
            break
        elif choice == '2':
            launch_organization()
            break
        else:
            print("Ошибка: введите 1 или 2.")

if __name__ == "__main__":
    main()
