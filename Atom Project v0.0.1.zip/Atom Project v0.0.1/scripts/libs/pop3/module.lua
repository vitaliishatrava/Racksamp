return {
  _NAME      = "pop3";
  _VERSION   = "0.1.7-dev";
  _COPYRIGHT = "Copyright (C) 2013-2016 Alexey Melnichuk";
  _LICENSE   = "MIT";
}